import React from 'react';
import ReactDOM from 'react-dom/client';
import './styles/index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { SellerProvider } from "./context/SellerContext";
// ✅ CONTEXT IMPORTS
import { CartProvider } from './context/CartContext';
import { AuthProvider } from './context/AuthContext';
import { ProductProvider } from './context/ProductContext';
import { OrderProvider } from "./context/OrderContext"; // 🔥 NEW
import { UIProvider } from './context/UIContext';
const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    <UIProvider>
      <SellerProvider>
        <OrderProvider>
          <AuthProvider>
            <ProductProvider> {/* 🔥 ADDED HERE */}
              <CartProvider>
                <App />
              </CartProvider>
            </ProductProvider>
          </AuthProvider>
        </OrderProvider>
      </SellerProvider>
    </UIProvider>
  </React.StrictMode>
);

reportWebVitals();