import {
  createContext,
  useContext,
  useState,
  useEffect,
} from "react";
const ProductContext = createContext();

export function ProductProvider({ children }) {
  const [products, setProducts] = useState(() => {

  const savedProducts =
    localStorage.getItem("products");

  return savedProducts
    ? JSON.parse(savedProducts)
    : [
        {
          id: 1,
          name: "Yarn Bundle Pack",
          price: 34.99,
          category: "crafts",
          type: "crochet",
          badge: "50% OFF",
          stock: 10,
          likes: 12,
          createdAt: Date.now(),
          sellerId: 999,
        },

        {
          id: 2,
          name: "Paint Set Deluxe",
          price: 29.99,
          category: "arts",
          type: "painting",
          badge: "Flash Sale",
          stock: 8,
          likes: 5,
          createdAt: Date.now(),
          sellerId: 998,
        },

        {
          id: 3,
          name: "Embroidery Kit",
          price: 24.99,
          category: "crafts",
          type: "embroidery",
          stock: 12,
          likes: 20,
          createdAt: Date.now(),
          sellerId: 997,
        },
      ];
});
  const [deals, setDeals] = useState(() => {

  const savedDeals =
    localStorage.getItem("deals");

  return savedDeals
    ? JSON.parse(savedDeals)
    : [
  {
    id: 1001,

    title: "Mega Crochet Bundle",

    sellerId: 999,

    products: [
      {
        id: 1,
        name: "Yarn Bundle Pack",
        category: "crafts",
        type: "crochet",
        price: 34.99,
      },
      {
        id: 3,
        name: "Embroidery Kit",
        category: "crafts",
        type: "embroidery",
        price: 24.99,
      },
    ],

    originalPrice: 59.98,

    discountedPrice: 39.99,

    validDate: "2026-12-30",

    images: [],
  },

  {
    id: 1002,

    title: "Painting Flash Sale",

    sellerId: 998,

    products: [
      {
        id: 2,
        name: "Paint Set Deluxe",
        category: "arts",
        type: "painting",
        price: 29.99,
      },
    ],

    originalPrice: 29.99,

    discountedPrice: 19.99,

    validDate: "2026-11-15",

    images: [],
  },
];
});

useEffect(() => {
  localStorage.setItem(
    "products",
    JSON.stringify(products)
  );
}, [products]);
useEffect(() => {

  localStorage.setItem(
    "deals",
    JSON.stringify(deals)
  );

}, [deals]);

  // 🔥 Add product (for later Step 9)
 const addProduct = (product, user) => {
  setProducts((prev) => [
    ...prev,

    {
      ...product,

      id: Date.now(),

      createdAt: Date.now(),

      sellerId: user.id,

      stock:
        Number(product.stock) || 0,

      likes:
        Number(product.likes) || 0,
    },
  ]);
};

const deleteProduct = (id) => {
  setProducts((prev) =>
    prev.filter((product) => product.id !== id)
  );
};

const updateProduct = (id, updatedData) => {
  setProducts((prev) =>
    prev.map((product) =>
      product.id === id
        ? { ...product, ...updatedData }
        : product
    )
  );
};
const createDeal = (dealData, user) => {
  setDeals((prev) => [
    ...prev,
    {
      id: Date.now(),
      sellerId: user.id,
      ...dealData,
    },
  ]);
};
const deleteDeal = (id) => {

  setDeals((prev) =>
    prev.filter(
      (deal) => deal.id !== id
    )
  );

};

const updateDeal = (
  id,
  updatedData
) => {

  setDeals((prev) =>
    prev.map((deal) =>
      deal.id === id
        ? {
            ...deal,
            ...updatedData,
          }
        : deal
    )
  );

};
const reduceStock = (cartItems) => {
  setProducts((prev) =>
    prev.map((product) => {
      const cartItem = cartItems.find(
        (item) => item.id === product.id
      );

      if (!cartItem) return product;

      return {
        ...product,
        stock: Math.max(
  0,
  product.stock - cartItem.quantity
),
      };
    })
  );
};

const toggleLike = (id) => {
  setProducts((prev) =>
    prev.map((product) =>
      product.id === id
        ? {
            ...product,
            likes:
              (product.likes || 0) + 1,
          }
        : product
    )
  );
};

  return (
    <ProductContext.Provider
 value={{
  products,
  deals,
  addProduct,
  deleteProduct,
  updateProduct,
  createDeal,
  deleteDeal,
  updateDeal,
  reduceStock,
  toggleLike,

}}
>
      {children}
    </ProductContext.Provider>
  );
}

export const useProducts = () => useContext(ProductContext);