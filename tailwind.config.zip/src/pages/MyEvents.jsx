export function MyEvents() {

  return (
    <div className="min-h-screen flex items-center justify-center">

      <h1 className="text-5xl text-white">
        My Events
      </h1>

    </div>
  );
}