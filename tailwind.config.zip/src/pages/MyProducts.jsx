import { useState } from "react";
import { motion } from "framer-motion";
import { useProducts } from "../context/ProductContext";
import { useAuth } from "../context/AuthContext";

export function MyProducts() {
  const { products, deleteProduct, updateProduct } = useProducts();
  const { user, role } = useAuth();

  const [editingId, setEditingId] = useState(null);

  const [editForm, setEditForm] = useState({});

  // 🔥 ONLY SELLER/BOTH
  if (role !== "seller" && role !== "both") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <span
          style={{
            fontFamily: "Pacifico",
            color: "#FF8FA3",
            fontSize: "36px",
            textShadow: "0 0 30px rgba(255,143,163,0.7)",
          }}
        >
          Seller access only
        </span>
      </div>
    );
  }

  const sellerProducts = products.filter(
    (p) => p.sellerId === user?.id
  );

  const inputStyle =
    "w-full px-4 py-3 rounded-[16px] bg-[#F6C1CC]/20 border-2 border-[#7A6C9D]/20 outline-none text-[#2E2A4A]";

  const handleEdit = (product) => {
    setEditingId(product.id);

    setEditForm({
      name: product.name,
      category: product.category,
      type: product.type,
      price: product.price,
      details: product.details || "",
      stock: product.stock,
      delivery: product.delivery || "",
      image: product.image || null,
    });
  };

  const handleSave = (id, oldProduct) => {
    const updated = {
      name: editForm.name || oldProduct.name,
      category: editForm.category || oldProduct.category,
      type: editForm.type || oldProduct.type,
      price: editForm.price || oldProduct.price,
      details: editForm.details || oldProduct.details,
      stock: editForm.stock || oldProduct.stock,
      delivery: editForm.delivery || oldProduct.delivery,
      image: editForm.image || oldProduct.image,
    };

    updateProduct(id, updated);

    setEditingId(null);
  };

  return (
    <div className="min-h-screen py-12 px-4 lg:px-20">
      <div className="max-w-[1440px] mx-auto">

        {/* HEADER */}
        <div className="text-center mb-12">
          <h1 className="text-5xl lg:text-6xl">

  <span
    style={{
      fontFamily: "Pacifico, cursive",
      color: "#FF8FA3",
      textShadow: "0 0 35px rgba(255,143,163,0.7)",
    }}
  >
    My{" "}
  </span>

  
    <span
    style={{
      fontFamily: "Fredoka, sans-serif",
      color: "#FFF6F8",
    }}
  >
    products
  </span>

</h1>
        </div>
<div className="flex justify-center mt-6">
  <a
    href="/upload"
    className="px-6 py-3 rounded-full bg-[#FF8FA3] text-white hover:scale-105 transition-all"
  >
    Upload Product
  </a>
</div>
        {sellerProducts.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">

            {sellerProducts.map((product) => (

              <motion.div
                key={product.id}
                whileHover={{ scale: 1.02 }}
                className="bg-[#FFF6F8]/90 rounded-[24px] p-6 shadow-xl"
              >

                {/* IMAGE */}
                <div className="aspect-square rounded-[20px] overflow-hidden bg-[#F6C1CC]/20 mb-4 flex items-center justify-center">

                  {product.image ? (
                    <img
                     src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="text-5xl">🧶</span>
                  )}
                </div>

                {/* NORMAL VIEW */}
                {editingId !== product.id ? (
                  <>
                    <h2 className="text-2xl text-[#2E2A4A] mb-2">
                      {product.name}
                    </h2>

                    <p className="text-[#7A6C9D] capitalize">
                      {product.category} • {product.type}
                    </p>

                    <p className="text-[#FF8FA3] text-2xl mt-2">
                      Rs. {product.price}
                    </p>

                    <p className="text-[#2E2A4A] mt-2">
                      Stock: {product.stock}
                    </p>

                    <p className="text-[#2E2A4A]">
                      ❤️ {product.likes || 0} Likes
                    </p>

                    <div className="flex gap-3 mt-6">

                      <button
                        onClick={() => handleEdit(product)}
                        className="flex-1 py-2 rounded-full bg-[#C8B6E2] text-[#2E2A4A]"
                      >
                        Edit
                      </button>

                      <button
                        onClick={() => {

  const confirmed = window.confirm(
    "Are you sure you want to delete this product?"
  );

  if (confirmed) {
    deleteProduct(product.id);
  }

}}
                        className="flex-1 py-2 rounded-full bg-[#FF8FA3] text-white"
                      >
                        Delete
                      </button>

                    </div>
                  </>
                ) : (

                  <>
                    {/* IMAGE UPDATE */}
                    <div className="mb-4">
                      <p className="text-[#7A6C9D] text-sm mb-2">
                        Update Product Image
                      </p>

                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
  const file = e.target.files[0];

  if (!file) return;

  const reader = new FileReader();

  reader.onloadend = () => {
    setEditForm({
      ...editForm,
      image: reader.result,
    });
  };

  reader.readAsDataURL(file);
}}
                        className={inputStyle}
                      />
                    </div>

                    {/* NAME */}
                    <input
                      placeholder={product.name}
                      value={editForm.name}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          name: e.target.value,
                        })
                      }
                      className={inputStyle + " mb-4"}
                    />

                    {/* PRICE */}
                    <input
                      type="number"
                      placeholder={product.price}
                      value={editForm.price}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          price: e.target.value,
                        })
                      }
                      className={inputStyle + " mb-4"}
                    />

                    {/* STOCK */}
                    <input
                      type="number"
                      placeholder={product.stock}
                      value={editForm.stock}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          stock: e.target.value,
                        })
                      }
                      className={inputStyle + " mb-4"}
                    />
                    <select
  value={editForm.category}
  onChange={(e) =>
    setEditForm({
      ...editForm,
      category: e.target.value,
      type: "",
    })
  }
  className={inputStyle + " mb-4"}
>
  <option value="">Select Category</option>
  <option value="crafts">Crafts</option>
  <option value="arts">Arts</option>
</select>
{editForm.category && (
  <select
    value={editForm.type}
    onChange={(e) =>
      setEditForm({
        ...editForm,
        type: e.target.value,
      })
    }
    className={inputStyle + " mb-4"}
  >

    <option value="">Select Subcategory</option>

    {editForm.category === "crafts" && (
      <>
        <option value="crochet">Crochet</option>
        <option value="knitting">Knitting</option>
        <option value="embroidery">Embroidery</option>
      </>
    )}

    {editForm.category === "arts" && (
      <>
        <option value="painting">Painting</option>
        <option value="sketching">Sketching</option>
        <option value="abstract">Abstract</option>
      </>
    )}

  </select>
)}
<textarea
  placeholder="Product Details"
  value={editForm.details}
  onChange={(e) =>
    setEditForm({
      ...editForm,
      details: e.target.value,
    })
  }
  className={inputStyle + " mb-4"}
/>

<input
  placeholder="Delivery Time"
  value={editForm.delivery}
  onChange={(e) =>
    setEditForm({
      ...editForm,
      delivery: e.target.value,
    })
  }
  className={inputStyle + " mb-4"}
/>
                    {/* SAVE */}
                    <button
                      onClick={() =>
                        handleSave(product.id, product)
                      }
                      className="w-full py-3 rounded-full bg-[#FF8FA3] text-white"
                    >
                      Save Changes
                    </button>
                  </>
                )}
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <span
              style={{
                fontFamily: "Pacifico",
                color: "#FF8FA3",
                fontSize: "38px",
                textShadow: "0 0 35px rgba(255,143,163,0.7)",
              }}
            >
              You have not uploaded any products yet
            </span>
          </div>
        )}
      </div>
    </div>
  );
}