export function MyTutorials() {

  return (
    <div className="min-h-screen flex items-center justify-center">

      <h1 className="text-5xl text-white">
        My Tutorials
      </h1>

    </div>
  );
}