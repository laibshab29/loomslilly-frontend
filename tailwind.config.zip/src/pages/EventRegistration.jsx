import { motion } from "framer-motion";
import { useState } from "react";

export function EventRegistration() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    event: "",
  });

  const [submitted, setSubmitted] = useState(false);

  const events = [
    "Spring Craft Fair",
    "Watercolor Workshop",
    "Crochet Circle Meetup",
    "Art Exhibition Opening",
    "Embroidery Masterclass",
    "Maker's Market",
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen py-12 px-4 lg:px-20">
      <div className="max-w-[600px] mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl lg:text-6xl mb-4">
            <span style={{ fontFamily: "Fredoka, sans-serif", color: "#FFF6F8" }}>
              Event{" "}
            </span>

            <span
              style={{
                fontFamily: "Pacifico, cursive",
                color: "#FF8FA3",
                textShadow: "0 0 30px rgba(255, 143, 163, 0.6)",
              }}
            >
              Registration
            </span>
          </h1>

          <p
            className="text-xl text-[#FFF6F8]"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Sign up for your favorite events
          </p>
        </motion.div>

        {/* Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-[24px] bg-[#FFF6F8]/90 backdrop-blur-sm border-2 border-[#7A6C9D]/20 p-8 shadow-2xl"
        >
          {submitted ? (
            <div className="text-center py-8">
              <div className="text-6xl mb-4">🎉</div>

              <h2
                className="text-3xl text-[#2E2A4A] mb-4"
                style={{ fontFamily: "Fredoka, sans-serif" }}
              >
                Registration Complete!
              </h2>

              <p
                className="text-[#7A6C9D] mb-6"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                We'll send you a confirmation email shortly
              </p>

              <button
                onClick={() => setSubmitted(false)}
                className="px-8 py-3 rounded-full bg-[#FF8FA3] text-white hover:bg-[#FF8FA3]/90 transition-all duration-300 hover:scale-105 shadow-lg"
                style={{ fontFamily: "Fredoka, sans-serif" }}
              >
                Register for Another Event
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name */}
              <div>
                <label
                  className="block text-[#2E2A4A] mb-2"
                  style={{ fontFamily: "Fredoka, sans-serif" }}
                >
                  Full Name
                </label>

                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  className="w-full px-4 py-3 rounded-[16px] bg-[#F6C1CC]/20 border-2 border-[#7A6C9D]/20 focus:border-[#FF8FA3] focus:outline-none transition-colors text-[#2E2A4A]"
                  placeholder="Enter your name"
                  style={{ fontFamily: "Inter, sans-serif" }}
                />
              </div>

              {/* Email */}
              <div>
                <label
                  className="block text-[#2E2A4A] mb-2"
                  style={{ fontFamily: "Fredoka, sans-serif" }}
                >
                  Email Address
                </label>

                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) =>
                    setFormData({ ...formData, email: e.target.value })
                  }
                  className="w-full px-4 py-3 rounded-[16px] bg-[#F6C1CC]/20 border-2 border-[#7A6C9D]/20 focus:border-[#FF8FA3] focus:outline-none transition-colors text-[#2E2A4A]"
                  placeholder="your@email.com"
                  style={{ fontFamily: "Inter, sans-serif" }}
                />
              </div>

              {/* Select */}
              <div>
                <label
                  className="block text-[#2E2A4A] mb-2"
                  style={{ fontFamily: "Fredoka, sans-serif" }}
                >
                  Select Event
                </label>

                <select
                  required
                  value={formData.event}
                  onChange={(e) =>
                    setFormData({ ...formData, event: e.target.value })
                  }
                  className="w-full px-4 py-3 rounded-[16px] bg-[#F6C1CC]/20 border-2 border-[#7A6C9D]/20 focus:border-[#FF8FA3] focus:outline-none transition-colors text-[#2E2A4A]"
                  style={{ fontFamily: "Inter, sans-serif" }}
                >
                  <option value="">Choose an event...</option>

                  {events.map((event) => (
                    <option key={event} value={event}>
                      {event}
                    </option>
                  ))}
                </select>
              </div>

              {/* Submit */}
              <button
                type="submit"
                className="w-full py-4 rounded-full bg-[#FF8FA3] text-white hover:bg-[#FF8FA3]/90 transition-all duration-300 hover:scale-105 shadow-lg text-lg"
                style={{ fontFamily: "Fredoka, sans-serif" }}
              >
                Register Now
              </button>
            </form>
          )}
        </motion.div>
      </div>
    </div>
  );
}