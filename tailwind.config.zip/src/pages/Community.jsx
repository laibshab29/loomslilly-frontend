import { motion } from "framer-motion";
import { MessageCircle, Users, Heart } from "lucide-react";
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";

// ✅ NEW IMPORT
import { useAuth } from "../context/AuthContext";

export function Community() {
  const { isGuest } = useAuth();

  const [joined, setJoined] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);

  // ✅ Persist terms acceptance
  useEffect(() => {
    const saved = localStorage.getItem("communityAccepted");
    if (saved === "true") {
      setAcceptedTerms(true);
    }
  }, []);

  const handleAcceptTerms = () => {
    localStorage.setItem("communityAccepted", "true");
    setAcceptedTerms(true);
  };

  const discussions = [
    { title: "Share Your Latest Projects!", replies: 156, likes: 342 },
    { title: "Tips for Beginners", replies: 89, likes: 234 },
    { title: "Color Combination Ideas", replies: 124, likes: 289 },
    { title: "Weekend Craft Challenge", replies: 67, likes: 198 },
    { title: "Tool Recommendations", replies: 203, likes: 456 },
    { title: "Pattern Sharing Thread", replies: 178, likes: 401 },
  ];

  return (
    <div className="min-h-screen py-12 px-4 lg:px-20">
      <div className="max-w-[1440px] mx-auto">

        {/* 🔒 GUEST BLOCK */}
        {isGuest && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-20"
          >
            <div className="text-7xl mb-6">🔒</div>

            <h2 className="text-3xl text-[#FFF6F8] mb-4">
              Sign up to join the community
            </h2>

            <Link
              to="/signup"
              className="px-8 py-4 rounded-full bg-[#FF8FA3] text-white hover:scale-105 transition-all"
            >
              Sign Up Now
            </Link>
          </motion.div>
        )}

        {/* 📜 TERMS SCREEN */}
        {!isGuest && !acceptedTerms && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-20"
          >
            <h2 className="text-4xl text-[#FFF6F8] mb-6">
              Community Guidelines
            </h2>

            <p className="text-[#FFF6F8] mb-8 max-w-xl mx-auto">
              Be respectful, avoid harmful content, and support fellow creators.
              By joining, you agree to follow our community standards.
            </p>

            <button
              onClick={handleAcceptTerms}
              className="px-10 py-4 rounded-full bg-[#FF8FA3] text-white hover:scale-105 transition-all"
            >
              Accept & Continue
            </button>
          </motion.div>
        )}

        {/* ✅ MAIN COMMUNITY CONTENT */}
        {!isGuest && acceptedTerms && (
          <>
            {/* Header */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-16"
            >
              <h1 className="text-5xl lg:text-7xl mb-4">
                <span
                  style={{
                    fontFamily: "Pacifico, cursive",
                    color: "#FF8FA3",
                    textShadow: "0 0 30px rgba(255, 143, 163, 0.6)",
                  }}
                >
                  Community
                </span>
              </h1>

              <p className="text-xl text-[#FFF6F8] mb-8">
                Connect with fellow creators and share your passion
              </p>

              {!joined && (
                <button
                  onClick={() => setJoined(true)}
                  className="px-12 py-4 rounded-full bg-[#FF8FA3] text-white hover:scale-105 transition-all"
                >
                  Join Community
                </button>
              )}
            </motion.div>

            {/* Joined State */}
            {joined && (
              <motion.div className="rounded-[24px] bg-[#C8B6E2]/20 p-8 mb-12 text-center">
                <h2 className="text-3xl text-[#FFF6F8] mb-2">
                  Welcome to the Community! 🎉
                </h2>
              </motion.div>
            )}

            {/* Stats */}
            <div className="grid md:grid-cols-2 gap-6 mb-12">
              <div className="rounded-[24px] bg-[#FFF6F8]/90 p-8 shadow-lg">
                <Users className="w-12 h-12 text-[#FF8FA3] mb-4" />
                <h3 className="text-2xl text-[#2E2A4A] mb-2">
                  15,000+ Members
                </h3>
              </div>

              <div className="rounded-[24px] bg-[#FFF6F8]/90 p-8 shadow-lg">
                <MessageCircle className="w-12 h-12 text-[#C8B6E2] mb-4" />
                <h3 className="text-2xl text-[#2E2A4A] mb-2">
                  Active Discussions
                </h3>
              </div>
            </div>

            {/* Discussions */}
            <div className="rounded-[24px] bg-[#FFF6F8]/90 p-8 shadow-lg">
              <h2 className="text-3xl text-[#2E2A4A] mb-6">
                Recent Discussions
              </h2>

              <div className="space-y-4">
                {discussions.map((discussion, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 rounded-[16px] bg-gradient-to-r from-[#F6C1CC]/20 to-[#C8B6E2]/20"
                  >
                    <h4 className="text-lg text-[#2E2A4A]">
                      {discussion.title}
                    </h4>

                    <div className="flex gap-6 text-[#7A6C9D]">
                      <span>{discussion.replies}</span>
                      <span>{discussion.likes}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}