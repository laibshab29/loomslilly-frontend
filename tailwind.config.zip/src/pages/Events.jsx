import { motion } from "framer-motion";
import { Calendar, MapPin, Users } from "lucide-react";
import { Link } from "react-router-dom";

// ✅ NEW
import { useAuth } from "../context/AuthContext";

export function Events() {
  const { isGuest } = useAuth();

  const events = [
    {
      name: "Spring Craft Fair",
      date: "April 15, 2026",
      location: "Downtown Arts Center",
      attendees: 245,
    },
    {
      name: "Watercolor Workshop",
      date: "April 20, 2026",
      location: "Creative Studio",
      attendees: 48,
    },
    {
      name: "Crochet Circle Meetup",
      date: "April 22, 2026",
      location: "Community Hall",
      attendees: 67,
    },
    {
      name: "Art Exhibition Opening",
      date: "April 28, 2026",
      location: "Modern Art Gallery",
      attendees: 189,
    },
    {
      name: "Embroidery Masterclass",
      date: "May 5, 2026",
      location: "Craft Haven",
      attendees: 32,
    },
    {
      name: "Maker's Market",
      date: "May 10, 2026",
      location: "City Square",
      attendees: 312,
    },
  ];

  return (
    <div className="min-h-screen py-12 px-4 lg:px-20">
      <div className="max-w-[1440px] mx-auto">
        
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl lg:text-7xl mb-4">
            <span style={{ fontFamily: "Fredoka, sans-serif", color: "#FFF6F8" }}>
              Upcoming{" "}
            </span>
            <span
              style={{
                fontFamily: "Pacifico, cursive",
                color: "#FF8FA3",
                textShadow: "0 0 30px rgba(255, 143, 163, 0.6)",
              }}
            >
              Events
            </span>
          </h1>

          <p className="text-xl text-[#FFF6F8]">
            Join us for workshops, exhibitions, and community gatherings
          </p>

          {/* ✅ Upload Button / Restriction */}
          <div className="mt-8">
            {isGuest ? (
              <Link
                to="/signup"
                className="px-10 py-4 rounded-full bg-[#C8B6E2] text-[#2E2A4A] hover:scale-105 transition-all"
              >
                Sign Up to Upload Event
              </Link>
            ) : (
              <Link
                to="/events/upload"
                className="px-10 py-4 rounded-full bg-[#FF8FA3] text-white hover:scale-105 transition-all shadow-lg"
              >
                Upload Event
              </Link>
            )}
          </div>
        </motion.div>

        {/* Event Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {events.map((event, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.03, y: -4 }}
              className="rounded-[20px] bg-[#FFF6F8]/90 backdrop-blur-sm border-2 border-[#7A6C9D]/20 overflow-hidden shadow-lg"
            >
              <div className="h-32 bg-gradient-to-br from-[#F6C1CC] to-[#C8B6E2] flex items-center justify-center text-5xl">
                🎨
              </div>

              <div className="p-6">
                <h3 className="text-xl text-[#2E2A4A] mb-4">
                  {event.name}
                </h3>

                <div className="space-y-2 mb-6 text-[#7A6C9D]">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <span>{event.date}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    <span>{event.location}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    <span>{event.attendees} attending</span>
                  </div>
                </div>

                <Link
                  to="/events/register"
                  className="block w-full py-3 rounded-full bg-[#FF8FA3] text-white text-center hover:scale-105 transition-all shadow-md"
                >
                  Register Now
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}