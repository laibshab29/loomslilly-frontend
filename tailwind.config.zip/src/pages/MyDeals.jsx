import { useAuth } from "../context/AuthContext";
import { useProducts } from "../context/ProductContext";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { useState } from "react";

export function MyDeals() {

  const {
  deals,
  deleteDeal,
  updateDeal,
} = useProducts();

  const { user, role } = useAuth();

  const navigate = useNavigate();

  const [editingId, setEditingId] =
  useState(null);

const [editForm, setEditForm] =
  useState({});

  if (
    role !== "seller" &&
    role !== "both"
  ) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <h1 className="text-4xl text-white">
          Seller access only
        </h1>
      </div>
    );
  }

  const myDeals = deals.filter(
    (deal) =>
      deal.sellerId === user?.id
  );
  const handleEdit = (deal) => {

  setEditingId(deal.id);

  setEditForm({

    title:
      deal.title,

    discountedPrice:
      deal.discountedPrice,

    validDate:
      deal.validDate,

    images:
      deal.images || [],

  });

};
const handleSave = (id) => {

  updateDeal(id, {
    ...editForm,
  });

  setEditingId(null);

};

  return (
    <div className="min-h-screen py-12 px-4 lg:px-20">

      <div className="max-w-[1440px] mx-auto">

        {/* HEADER */}
        <div className="text-center mb-12">

          <h1 className="text-6xl mb-6">

            <span
              style={{
                fontFamily: "Pacifico",
                color: "#FF8FA3",
                textShadow:
                  "0 0 35px rgba(255,143,163,0.7)",
              }}
            >
              My
            </span>

            <span
              className="text-white"
              style={{
                fontFamily: "Fredoka",
              }}
            >
              {" "}Deals
            </span>

          </h1>

          <button
            onClick={() =>
              navigate("/deals")
            }
            className="px-8 py-4 rounded-full bg-[#FF8FA3] text-white hover:scale-105 transition-all"
          >
            Create New Deal
          </button>

        </div>

        {/* EMPTY */}
        {myDeals.length === 0 ? (

          <div className="text-center py-20 text-white text-2xl">
            You have not created any deals yet
          </div>

        ) : (

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

            {myDeals.map((deal) => (

  <motion.div
    key={deal.id}
    whileHover={{
      scale: 1.02,
    }}
    className="rounded-[28px] overflow-hidden p-6 bg-gradient-to-br from-[#F6C1CC] to-[#C8B6E2] shadow-xl"
  >

    {editingId !== deal.id ? (

      <>
        <Link to={`/deals/${deal.id}`}>

          {deal.images?.length > 0 && (

            <img
              src={deal.images[0]}
              alt={deal.title}
              className="w-full h-[240px] object-cover rounded-[20px] mb-4"
            />

          )}

          <h2
            className="text-3xl mb-4"
            style={{
              fontFamily: "Pacifico",
              color: "#FFF6F8",
            }}
          >
            {deal.title}
          </h2>

          <div className="flex flex-wrap gap-2 mb-4">

            {deal.products.map((product) => (

              <div
                key={product.id}
                className="px-3 py-2 rounded-full bg-white text-[#2E2A4A]"
              >
                {product.name}
              </div>

            ))}

          </div>

          <div className="text-white">

            <p>
              Original:
              Rs. {deal.originalPrice}
            </p>

            <p className="text-2xl">
              Deal:
              Rs. {deal.discountedPrice}
            </p>

            <p className="mt-2 text-white/80">
              Valid Until:
              {" "}
              {deal.validDate}
            </p>

          </div>

        </Link>

        <div className="flex gap-3 mt-6">

          <button
            onClick={() =>
              handleEdit(deal)
            }
            className="flex-1 py-3 rounded-full bg-white text-[#2E2A4A]"
          >
            Edit
          </button>

          <button
            onClick={() => {

              const confirmed =
                window.confirm(
                  "Delete this deal?"
                );

              if (confirmed) {
                deleteDeal(deal.id);
              }

            }}
            className="flex-1 py-3 rounded-full bg-red-500 text-white"
          >
            Delete
          </button>

        </div>
      </>

    ) : (

      <div className="bg-white rounded-[24px] p-6">

        <input
          value={editForm.title}
          onChange={(e) =>
            setEditForm({
              ...editForm,
              title: e.target.value,
            })
          }
          className="w-full px-4 py-3 rounded-[16px] mb-4 bg-[#F6C1CC]/20"
        />

        <input
          type="number"
          value={editForm.discountedPrice}
          onChange={(e) =>
            setEditForm({
              ...editForm,
              discountedPrice:
                e.target.value,
            })
          }
          className="w-full px-4 py-3 rounded-[16px] mb-4 bg-[#F6C1CC]/20"
        />

        <input
          type="date"
          value={editForm.validDate}
          onChange={(e) =>
            setEditForm({
              ...editForm,
              validDate:
                e.target.value,
            })
          }
          className="w-full px-4 py-3 rounded-[16px] mb-6 bg-[#F6C1CC]/20"
        />

        <div className="flex gap-3">

          <button
            onClick={() =>
              handleSave(deal.id)
            }
            className="flex-1 py-3 rounded-full bg-[#FF8FA3] text-white"
          >
            Save
          </button>

          <button
            onClick={() =>
              setEditingId(null)
            }
            className="flex-1 py-3 rounded-full bg-gray-300"
          >
            Cancel
          </button>

        </div>

      </div>

    )}

  </motion.div>

))}

          </div>

        )}

      </div>

    </div>
  );
}