import { motion } from "framer-motion";
import { Play, Clock, User } from "lucide-react";
import { Link } from "react-router-dom";

// ✅ NEW
import { useAuth } from "../context/AuthContext";

export function Tutorials() {
  const { isGuest } = useAuth();

  const tutorials = [
    { title: "Beginner Crochet Basics", duration: "15 min", creator: "Sarah M.", thumbnail: "🧶" },
    { title: "Watercolor Techniques", duration: "22 min", creator: "Alex K.", thumbnail: "🎨" },
    { title: "Advanced Knitting Patterns", duration: "30 min", creator: "Emma L.", thumbnail: "🧵" },
    { title: "Embroidery Stitches Guide", duration: "18 min", creator: "Maria P.", thumbnail: "🪡" },
    { title: "Abstract Painting Methods", duration: "25 min", creator: "Chris B.", thumbnail: "🖼️" },
    { title: "Sketching Portraits", duration: "35 min", creator: "David R.", thumbnail: "✏️" },
    { title: "Amigurumi Animals", duration: "28 min", creator: "Lisa T.", thumbnail: "🐻" },
    { title: "Oil Painting Basics", duration: "40 min", creator: "James W.", thumbnail: "🎨" },
  ];

  return (
    <div className="min-h-screen py-12 px-4 lg:px-20">
      <div className="max-w-[1440px] mx-auto">

        {/* 🔒 GUEST BLOCK */}
        {isGuest && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-20"
          >
            <div className="text-7xl mb-6">🔒</div>

            <h2 className="text-3xl text-[#FFF6F8] mb-4">
              Sign up to access tutorials
            </h2>

            <Link
              to="/signup"
              className="px-8 py-4 rounded-full bg-[#FF8FA3] text-white hover:scale-105 transition-all"
            >
              Sign Up Now
            </Link>
          </motion.div>
        )}

        {/* ✅ MAIN CONTENT */}
        {!isGuest && (
          <>
            {/* Header */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-16"
            >
              <h1 className="text-5xl lg:text-7xl mb-4">
                <span
                  style={{
                    fontFamily: "Pacifico, cursive",
                    color: "#FF8FA3",
                    textShadow: "0 0 30px rgba(255, 143, 163, 0.6)",
                  }}
                >
                  Tutorials
                </span>
              </h1>

              <p className="text-xl text-[#FFF6F8]">
                Learn from our talented community of creators
              </p>

              {/* ✅ Upload Button */}
              <div className="mt-8">
                <Link
                  to="/tutorials/upload"
                  className="px-10 py-4 rounded-full bg-[#FF8FA3] text-white hover:scale-105 transition-all shadow-lg"
                >
                  Upload Tutorial
                </Link>
              </div>
            </motion.div>

            {/* Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {tutorials.map((tutorial, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.03, y: -4 }}
                  className="rounded-[20px] bg-[#FFF6F8]/90 backdrop-blur-sm border-2 border-[#7A6C9D]/20 overflow-hidden shadow-lg group cursor-pointer"
                >
                  <div className="aspect-video bg-gradient-to-br from-[#F6C1CC]/50 to-[#C8B6E2]/50 flex items-center justify-center relative">
                    <div className="text-6xl">{tutorial.thumbnail}</div>

                    <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 flex items-center justify-center">
                      <div className="w-16 h-16 rounded-full bg-[#FF8FA3] flex items-center justify-center">
                        <Play className="w-8 h-8 text-white fill-white ml-1" />
                      </div>
                    </div>
                  </div>

                  <div className="p-4">
                    <h3 className="text-lg text-[#2E2A4A] mb-3">
                      {tutorial.title}
                    </h3>

                    <div className="flex items-center justify-between text-sm text-[#7A6C9D]">
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{tutorial.duration}</span>
                      </div>

                      <div className="flex items-center gap-1">
                        <User className="w-4 h-4" />
                        <span>{tutorial.creator}</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}