import { Link, useNavigate } from "react-router-dom";
import { ShoppingCart } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useUI } from "../context/UIContext"; // ✅ NEW
import { User } from "lucide-react";

import logo from "../assets/logo.jpeg";

export function Navbar() {
  const { isGuest, logout, user, role } = useAuth();
  const navigate = useNavigate();
  const { setTransitionMode } = useUI(); // ✅ FIXED

  const navLinks = [
    { label: "Crafts", path: "/crafts" },
    { label: "Arts", path: "/arts" },
    { label: "Tutorials", path: "/tutorials" },
    { label: "Deals", path: "/deals" },
    { label: "Community", path: "/community" },
    { label: "Events", path: "/events" },
    { label: "New Arrivals", path: "/new-arrivals" },
    { label: "Trending", path: "/trending" },
  ];

  // ✅ LOGO CLICK TRANSITION
  const handleLogoClick = () => {
    setTransitionMode("quick");

    setTimeout(() => {
      navigate("/");
      setTransitionMode(null);
    }, 500); // fast transition (as you wanted)
  };

  return (
    <div className="relative z-50 mt-14">

      <nav className="mx-4 lg:mx-20 relative">

        <div className="max-w-[1440px] mx-auto bg-[#FFF6F8]/80 backdrop-blur-md rounded-[30px] pl-56 pr-6 py-4 shadow-lg border-2 border-[#7A6C9D]/30 relative overflow-visible">

          {/* CUT MASK */}
          <div className="absolute left-0 top-1/2 -translate-y-1/2 w-48 h-48 bg-[#5B4B73] rounded-full z-10"></div>

          {/* LOGO */}
          <div
            onClick={handleLogoClick}
            className="absolute left-[-1px] top-[50%] -translate-y-1/2 z-50 cursor-pointer"
          >
            <div className="w-48 h-48 rounded-full">

              <div className="w-full h-full rounded-full p-[4px] bg-[#FF8FA3] shadow-[0_0_15px_rgba(255,143,163,0.5)]">

                <div className="w-full h-full rounded-full overflow-hidden bg-[#5B4B73]">
                  <img
                    src={logo}
                    alt="LoomsLilly Logo"
                    className="w-full h-full object-cover scale-115"
                  />
                </div>

              </div>
            </div>
          </div>

          <div className="flex items-center justify-between gap-6 relative z-20">

            {/* NAV LINKS */}
            <div className="hidden lg:flex items-center gap-2 flex-1 justify-center">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className="px-4 py-2 rounded-full text-[#2E2A4A] hover:bg-[#F6C1CC]/50 transition-all duration-300 hover:scale-105 whitespace-nowrap"
                  style={{ fontFamily: "Fredoka, sans-serif" }}
                >
                  {link.label}
                </Link>
              ))}
            </div>

            {/* RIGHT SIDE */}
            <div className="flex items-center gap-3 flex-shrink-0">

              {/* CART */}
              {role !== "seller" && (
  <Link
    to="/cart"
    className="p-3 rounded-full bg-[#C8B6E2]/30 hover:bg-[#C8B6E2]/50 transition-all duration-300 hover:scale-110"
  >
    <ShoppingCart className="w-5 h-5 text-[#2E2A4A]" />
  </Link>
)}
              {/* AUTH */}
              {isGuest ? (
                <>
                  <div className="flex flex-col gap-1">
                    <Link
                      to="/signup?mode=login"
                      className="px-4 py-1 text-xs rounded-full bg-[#FF8FA3] text-white text-center"
                    >
                      Log In
                    </Link>

                    <Link
                      to="/signup"
                      className="px-4 py-1 text-xs rounded-full bg-[#FF8FA3] text-white text-center"
                    >
                      Sign Up
                    </Link>
                  </div>

                  <Link
                    to="/community"
                    className="px-5 py-2 rounded-full bg-[#C8B6E2] text-[#2E2A4A]"
                  >
                    Join Community
                  </Link>
                </>
              ) : (
                <>
                  <Link
                    to="/account"
                    className="flex items-center gap-2 px-5 py-2 rounded-full bg-[#C8B6E2] text-[#2E2A4A] hover:scale-105 transition-all"
                      >
                    <User className="w-5 h-5 text-[#2E2A4A]" />

                    <span>
                      {user?.name || "Account"}
                    </span>
                  </Link>

                  <button
                    onClick={logout}
                    className="px-5 py-2 rounded-full bg-[#FF8FA3] text-white"
                  >
                    Logout
                  </button>
                </>
              )}
            </div>
          </div>

          {/* MOBILE */}
          <div className="lg:hidden mt-4 flex flex-wrap gap-2 relative z-20">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className="px-3 py-1.5 rounded-full text-sm text-[#2E2A4A] bg-[#F6C1CC]/30"
              >
                {link.label}
              </Link>
            ))}
          </div>

        </div>
      </nav>
    </div>
  );
}