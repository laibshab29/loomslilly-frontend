import { useMemo } from "react";

export function CreateDealForm({
  sellerProducts,
  dealForm,
  setDealForm,
  handleCreateDeal,
}) {

  // 🔥 SELECTED PRODUCTS
  const selectedProducts = sellerProducts.filter(
    (product) =>
      dealForm.productIds.includes(
        String(product.id)
      )
  );

  // 🔥 ORIGINAL PRICE
  const originalPrice = useMemo(() => {
    return selectedProducts.reduce(
      (total, product) =>
        total + Number(product.price),
      0
    );
  }, [selectedProducts]);

  return (
    <div className="max-w-[700px] mx-auto bg-[#FFF6F8]/90 rounded-[28px] p-8 shadow-xl">

      {/* TITLE */}
      <div className="mb-6">

        <label className="block text-[#7A6C9D] mb-2">
          Title
        </label>

        <input
          placeholder="Flash Sale"
          value={dealForm.title}
          onChange={(e) =>
            setDealForm({
              ...dealForm,
              title: e.target.value,
            })
          }
          className="w-full px-4 py-3 rounded-[16px] bg-[#F6C1CC]/20"
        />

      </div>

      {/* PRODUCTS */}
      <div className="mb-6">

        <label className="block text-[#7A6C9D] mb-3">
          Select Products
        </label>

        {dealForm.productIds.map(
          (selectedId, index) => {

            const alreadySelected =
              dealForm.productIds.filter(Boolean);

            return (
              <select
                key={index}
                value={selectedId}
                onChange={(e) => {

                  const updated = [
                    ...dealForm.productIds,
                  ];

                  updated[index] =
                    e.target.value;

                  setDealForm({
                    ...dealForm,
                    productIds: updated,
                  });
                }}
                className="w-full px-4 py-3 rounded-[16px] mb-4 bg-[#F6C1CC]/20"
              >

                <option value="">
                  Select Product
                </option>

                {sellerProducts
                  .filter(
                    (product) =>
                      !alreadySelected.includes(
                        String(product.id)
                      ) ||
                      String(product.id) === selectedId
                  )
                  .map((product) => (
                    <option
                      key={product.id}
                      value={product.id}
                    >
                      {product.name}
                    </option>
                  ))}
              </select>
            );
          }
        )}

        {/* ADD PRODUCT */}
        {dealForm.productIds.length < 5 ? (

          <button
            type="button"
            onClick={() => {

              if (
                sellerProducts.length <=
                dealForm.productIds.length
              ) {
                alert(
                  "You do not have enough uploaded products."
                );

                return;
              }

              setDealForm({
                ...dealForm,
                productIds: [
                  ...dealForm.productIds,
                  "",
                ],
              });
            }}
            className="px-5 py-2 rounded-full bg-[#C8B6E2] text-[#2E2A4A]"
          >
            + Add Another Product
          </button>

        ) : (

          <p className="text-[#FF8FA3]">
            Maximum 5 products allowed
          </p>

        )}
      </div>

      {/* ORIGINAL PRICE */}
      <div className="mb-6">

        <label className="block text-[#7A6C9D] mb-2">
          Original Price
        </label>

        <input
          disabled
          value={`Rs. ${originalPrice}`}
          className="w-full px-4 py-3 rounded-[16px] bg-gray-200 text-[#2E2A4A]"
        />

      </div>

      {/* DISCOUNTED PRICE */}
      <div className="mb-6">

        <label className="block text-[#7A6C9D] mb-2">
          Discounted Price
        </label>

        <input
          type="number"
          value={dealForm.discountedPrice}
          onChange={(e) => {

            const value =
              Number(e.target.value);

            if (value < 1) return;

            if (
              value > originalPrice
            ) return;

            setDealForm({
              ...dealForm,
              discountedPrice:
                e.target.value,
            });
          }}
          className="w-full px-4 py-3 rounded-[16px] bg-[#F6C1CC]/20"
        />

      </div>

      {/* VALID DATE */}
      <div className="mb-6">

        <label className="block text-[#7A6C9D] mb-2">
          Valid Until
        </label>

        <input
          type="date"
          min={
            new Date(
              Date.now() + 86400000
            )
              .toISOString()
              .split("T")[0]
          }
          value={dealForm.validDate}
          onChange={(e) => {

  const files = Array.from(e.target.files);

  if (files.length > 10) {
    alert("Maximum 10 images allowed");
    return;
  }

  Promise.all(
    files.map((file) => {
      return new Promise((resolve) => {

        const reader = new FileReader();

        reader.onloadend = () => {
          resolve(reader.result);
        };

        reader.readAsDataURL(file);
      });
    })
  ).then((base64Images) => {

    setDealForm({
      ...dealForm,
      images: base64Images,
    });

  });

}}
          className="w-full px-4 py-3 rounded-[16px] bg-[#F6C1CC]/20"
        />

      </div>

      {/* IMAGES */}
      <div className="mb-8">

        <label className="block text-[#7A6C9D] mb-2">
          Upload Deal Images
        </label>

        <input
          type="file"
          multiple
          accept="image/*"
          onChange={(e) => {

            const files =
              Array.from(e.target.files);

            if (files.length > 10) {
              alert(
                "Maximum 10 images allowed"
              );

              return;
            }

            setDealForm({
              ...dealForm,
              images: files,
            });
          }}
          className="w-full px-4 py-3 rounded-[16px] bg-[#F6C1CC]/20"
        />

      </div>

      {/* PUBLISH */}
      <button
        onClick={() =>
          handleCreateDeal(
            selectedProducts,
            originalPrice
          )
        }
        className="w-full py-4 rounded-full bg-[#FF8FA3] text-white hover:scale-[1.02] transition-all"
      >
        Publish Deal
      </button>

    </div>
  );
}